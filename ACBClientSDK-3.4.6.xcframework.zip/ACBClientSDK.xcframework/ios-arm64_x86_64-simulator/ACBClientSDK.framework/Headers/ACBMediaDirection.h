#import <Foundation/Foundation.h>

/**
    Used to specify the required direction of media when creating or answering a call.
 */
typedef NS_ENUM(NSUInteger, ACBMediaDirection)
{
    ACBMediaDirectionNone,
    ACBMediaDirectionSendOnly,
    ACBMediaDirectionReceiveOnly,
    ACBMediaDirectionSendAndReceive
};

