#import <UIKit/UIKit.h>
#import <AVFoundation/AVCaptureDevice.h>

#import <ACBClientSDK/ACBMediaDirection.h>
#import <ACBClientSDK/ACBVideoCaptureResolution.h>
#import <ACBClientSDK/ACBVideoCaptureSetting.h>

@protocol ACBClientCallDelegate;
@class ACBClientCall;
@class ACBClientPhone;
@class ACBAudioDeviceManager;

NS_ASSUME_NONNULL_BEGIN

/**
 The phone's delegate.
 */
@protocol ACBClientPhoneDelegate <NSObject>

@required

/**
 A notification to indicate an incoming call.
 
 @param phone The phone receiving the call.
 @param call The incoming call.
 */
- (void) phone:(ACBClientPhone*)phone didReceiveCall:(ACBClientCall*)call;

@optional

/**
 A notification that video is being captured at a specified resolution and frame-rate. Depending on the capabilities of the device, these settings may be different from the preferred resolution and framerate set on the phone.
 
 @param phone The phone object.
 @param settings The new capture settings.
 @param camera The capturing camera.
 */
- (void) phone:(ACBClientPhone*)phone didChangeCaptureSetting:(ACBVideoCaptureSetting*)settings forCamera:(AVCaptureDevicePosition)camera;

@end

/**
 An object that acts as the entry point for all voice and video calls.
 */
@interface ACBClientPhone : NSObject

/** The delegate. */
@property (weak, nullable) id<ACBClientPhoneDelegate> delegate;

/** An array of calls that are currently in progress. */
@property (readonly) NSArray<ACBClientCall *> *currentCalls;
/** The UIView for displaying the preview image */
@property (strong, nullable) UIView *previewView;

/** If true, the preview view is mirrored when using a front-facing camera (see [setCamera:]). Does not affect video sent to callee. */
@property (nonatomic, assign) BOOL mirrorFrontFacingCameraPreview;
/** Manages audio session */
@property (readonly) ACBAudioDeviceManager *audioDeviceManager;

/** The preferred capture resolution. If no preferred resolution is specified, the best SD resolution that the device is capable of will be chosen. */
@property ACBVideoCaptureResolution preferredCaptureResolution;
/** The preferred capture framerate. If no preferred frame rate is specified, the best frame rate that the device is capable of will be chosen. */
@property NSUInteger preferredCaptureFrameRate;

/**
 Deprecated; please use [createCallToAddress:withAudio:video:delegate].
 
 @param address The remote address.
 @param audio Whether to use audio.
 @param video Whether to use video.
 @param delegate The call delegate.
 @return ACBClientCall Successfully created call object
 */
- (nullable ACBClientCall *) createCallToAddress:(NSString*)address
                                           audio:(BOOL)audio
                                           video:(BOOL)video
                                        delegate:(nullable id<ACBClientCallDelegate>)delegate
                                        __deprecated_msg("Use ACBMediaDirection for audio and video parameters.");

/**
 Creates a call to the given remote address.
 
 A call must be created with media. In other words, specifying both audio and
 video direction as ACBMediaDirectionNone will result in a call failure.
 
 Note that the SDK only supports one call at a time. If you attempt to create
 a call whilst another is already in pregress, then the call creation will fail.
 
 @param address     The remote address.
 @param audioDirection       The media direction required for audio.
 @param videoDirection       The media direction required for video.
 @param delegate    The call delegate.
 @return ACBClientCall Successfully created call object
 */
- (nullable ACBClientCall *) createCallToAddress:(NSString *)address
                                       withAudio:(ACBMediaDirection)audioDirection
                                           video:(ACBMediaDirection)videoDirection
                                        delegate:(nullable id<ACBClientCallDelegate>)delegate;

/**
 Deprecated. Video orientation is handled automatically, this method does nothing.
 */
- (void) setVideoOrientation:(UIInterfaceOrientation)orientation __deprecated_msg("Video orientation is handled automatically, this method does nothing.");


/**
 Sets the camera to use as the video source.
 
 @param camera The camera to use as the video source.
 */
- (void) setCamera:(AVCaptureDevicePosition)camera;
/**
 Returns an array of ACBVideoCaptureSetting objects that represent the recommended resolutions and frame-rates that the device is capable of. Settings are ordered from highest resolution to lowest resolution.
 
 @return recommended resolutions and frame-rates.
 */
- (NSArray<ACBVideoCaptureSetting *> *)recommendedCaptureSettings;

/**
 Requests the user's permission to access the microphone and/or camera.
 
 Microphone and camera permissions in iOS function at an application-level and not per-call. Therefore this method should typically be
 called before making or receiving calls.
 
 An individual alert will be displayed for each requested permission. The alert will be displayed the first time you call
 this method. Subsequent calls will not display an alert unless you have reset your privacy settings in iOS Settings. This method
 is asynchronous and will return before the alerts have been answered.
 
 This method defers to AVCaptureDevice requestAccessForMediaType - please see the iOS Developer Library for further information.
 
 @param audio request permission to use the microphone.
 @param video request permission to use the camera.
 */
+ (void)requestMicrophoneAndCameraPermission:(BOOL)audio video:(BOOL)video __deprecated_msg("Use [ACBClientPhone requestPermissionForMicrophone:camera:completion:] or handle it directly in the app with [AVCaptureDevice requestAccessForMediaType:completionHandler:]");

/**
 Requests the user's permission to access the microphone and/or camera.
 
 Microphone and camera permissions in iOS function at an application-level and not per-call. Therefore this method should typically be
 called before making or receiving calls.
 
 An individual alert will be displayed for each requested permission. The alert will be displayed the first time you call
 this method. Subsequent calls will not display an alert unless you have reset your privacy settings in iOS Settings. This method
 is asynchronous and will call the given block on completion.
 
 This method defers to AVCaptureDevice requestAccessForMediaType - please see the iOS Developer Library for further information.
 
 @param microphone request permission to use the microphone.
 @param camera request permission to use the camera.
 @param completion the completion block that's fired after user interaction is complete (on the main thread).
 */
+ (void)requestPermissionForMicrophone:(BOOL)microphone camera:(BOOL)camera completion:(void (^)(void))completion;

@end

NS_ASSUME_NONNULL_END
