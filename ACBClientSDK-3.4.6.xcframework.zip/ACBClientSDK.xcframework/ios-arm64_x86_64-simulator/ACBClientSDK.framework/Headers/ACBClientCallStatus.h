#import <Foundation/Foundation.h>

/**
 Call status changes: they can only increase the value.

 Outgoing calls and incoming OFFER_REQUESTs:
 Setup --> MediaOpened (not notified to user) --> Connecting (not notified to user) --> MediaPending --> (Ringing) -->InCall -->Ended

 Incoming calls:
 Setup --> Alerting --> (not "Connecting") -- > MediaPending --> InCall --> Ended

 Beware: these values are in order of progress, so that it is possible to check that the status is somewhere between a min and a max (e.g. Setup and InCall).
 */
typedef NS_ENUM(NSUInteger, ACBClientCallStatus)
{
    /** Indicates the call is in a process of being setup. */
    ACBClientCallStatusSetup,
    /** Indicates the call is ringing/alerting locally - incoming call. */
    ACBClientCallStatusAlerting,
    /** Indicates the call is ringing on the remote side - outgoing call. */
    ACBClientCallStatusRinging,
    /** Indicates the call is connected and we're waiting for media streams to establish. */
    ACBClientCallStatusMediaPending,
    /** Indicates the call is in progress including media. */
    ACBClientCallStatusInCall,
    /** Indicates the dialled operation timed out. */
    ACBClientCallStatusTimedOut,
    /** Indicates the dialled number is busy. */
    ACBClientCallStatusBusy,
    /** Indicates the dialled number was unreachable. */
    ACBClientCallStatusNotFound,
    /** Indicates the call has errored. */
    ACBClientCallStatusError,
    /** Indicates the call has ended. */
    ACBClientCallStatusEnded
};
