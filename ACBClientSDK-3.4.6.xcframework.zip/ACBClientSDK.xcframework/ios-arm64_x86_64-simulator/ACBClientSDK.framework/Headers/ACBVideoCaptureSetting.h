#import <UIKit/UIKit.h>

#import <ACBClientSDK/ACBVideoCaptureResolution.h>

NS_ASSUME_NONNULL_BEGIN

/**
 An  object that represents a resolution and frame rate. An NSArray of these objects is returned from the recommendedCaptureSettings method.
 */
@interface ACBVideoCaptureSetting : NSObject

/** The capture resolution. */
@property (readonly) ACBVideoCaptureResolution resolution;
/** The capture frame rate. */
@property (readonly) NSUInteger frameRate;

/**
 Converts a ACBVideoCaptureResolution enum into the width and height for that resolution. Note that this doesn't take orientation into account and will always return landscape values.
 
 @param resolution The resolution to convert.
 @return a CGSize containing the resolution's width and height
 */
+ (CGSize) sizeForVideoCaptureResolution:(ACBVideoCaptureResolution)resolution;

@end

NS_ASSUME_NONNULL_END
