#import <Foundation/Foundation.h>

/**
 Advanced options that can be specified when creating the ACBUC object (see
 [ucWithConfiguration:stunServers:delegate:options:]). Most applications will not need to use these options, and
 should use one of the other [ucWithConfiguration...] functions instead.
 */
typedef NS_OPTIONS(NSUInteger, ACBUCOptions)
{
    /** Equivalent to not specifying any options. */
    ACBUCOptionNone = 0,
    
    /**
     Specifying this option replaces the iOS system echo cancellation (provided by the Voice Processing Audio Unit)
     with an alternative software-based echo cancellation algorithm. Most applications will find the default
     behaviour to provide the best performance, but this option may be worth experimenting with in case of echo
     problems.
     */
    ACBUCOptionUseSoftwareEchoCancellation = 1 << 0,
    
    /**
     Specifying this option disables iOS system voice processing (provided by the Voice Processing Audio Unit)
     and does not use any form of echo cancellation. Note that ACBUCOptionUseSoftwareEchoCancellation has no effect
     if ACBUCOptionNoVoiceProcessing is specified.
     */
    ACBUCOptionNoVoiceProcessing = 1 << 1
};
