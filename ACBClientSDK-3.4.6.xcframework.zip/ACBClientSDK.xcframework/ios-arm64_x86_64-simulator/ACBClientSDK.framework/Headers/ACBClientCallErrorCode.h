#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, ACBClientCallErrorCode)
{
    /** Indicates that a general error has occurred when making an outgoing call. */
    ACBClientCallErrorCodeDialFailure,
    /** Indicates that an attempt to make an outbound call failed because a call is already in progress. */
    ACBClientCallErrorCodeDialFailureCallInProgress,
    /** Indicates that a general error has occurred with an established call. */
    ACBClientCallErrorCodeCallFailure,
    /** Indicates that the call was in the wrong state when an answer has been received. */
    ACBClientCallErrorCodeWrongStateWhenAnswerReceived,
    /** Indicates that a session description could not be created. */
    ACBClientCallErrorCodeSessionDescriptionCreationError,
};

typedef NS_ENUM(NSUInteger, ACBClientCallError)
{
    ACBClientCallErrorDialFailure __deprecated_enum_msg("Deprecated - use ACBClientCallErrorCodeDialFailure instead") = ACBClientCallErrorCodeDialFailure,
    
    ACBClientCallErrorDialFailureCallInProgress __deprecated_enum_msg("Deprecated - use ACBClientCallErrorCodeDialFailureCallInProgress instead") = ACBClientCallErrorCodeDialFailureCallInProgress,
    
    ACBClientCallErrorCallFailure __deprecated_enum_msg("Deprecated - use ACBClientCallErrorCodeCallFailure instead") = ACBClientCallErrorCodeCallFailure,
    
    ACBClientCallErrorWrongStateWhenAnswerReceived __deprecated_enum_msg("Deprecated - use ACBClientCallErrorCodeWrongStateWhenAnswerReceived instead") = ACBClientCallErrorCodeWrongStateWhenAnswerReceived,
    
    ACBClientCallErrorSessionDescriptionCreationError __deprecated_enum_msg("Deprecated - use ACBClientCallErrorCodeSessionDescriptionCreationError instead") = ACBClientCallErrorCodeSessionDescriptionCreationError,
};
