#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

#import <ACBClientSDK/ACBAudioDevice.h>

NS_ASSUME_NONNULL_BEGIN

@interface ACBAudioDeviceManager : NSObject
- (void) start;
- (void) stop;
- (void) setDefaultAudio: (ACBAudioDevice) device;
- (BOOL) setAudioDevice: (ACBAudioDevice) device;
- (void) refreshSpeakerphoneSetting;
- (ACBAudioDevice) selectedAudioDevice;
// Returns an array of ACBAudioDevice values, encoded as NSNumbers
- (NSArray<NSNumber *> *)audioDevices;
@end

NS_ASSUME_NONNULL_END
