#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, ACBClientCallProvisionalResponse) {
    /** Ignored */
    ACBClientCallProvisionalResponseIgnored,
    /** Indicates a ringing event */
    ACBClientCallProvisionalResponseRinging,
    /** Indicaates call is being forwarded */
    ACBClientCallProvisionalResponseBeingForwarded,
    /** Indicates call is queued */
    ACBClientCallProvisionalResponseQueued,
    /** Indicates general call progress */
    ACBClientCallProvisionalResponseSessionProgress
};
