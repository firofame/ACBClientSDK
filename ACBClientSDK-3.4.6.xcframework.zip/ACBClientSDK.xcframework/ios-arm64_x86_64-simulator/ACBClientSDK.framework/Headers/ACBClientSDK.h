// Backward compatibility for apps that still may be using ACBView in code.
#define ACBView UIView

#import <Foundation/Foundation.h>

#import <ACBClientSDK/ACBAudioDevice.h>
#import <ACBClientSDK/ACBAudioDeviceManager.h>
#import <ACBClientSDK/ACBClientAED.h>
#import <ACBClientSDK/ACBClientCall.h>
#import <ACBClientSDK/ACBClientCallErrorCode.h>
#import <ACBClientSDK/ACBClientCallProvisionalResponse.h>
#import <ACBClientSDK/ACBClientCallStatus.h>
#import <ACBClientSDK/ACBClientPhone.h>
#import <ACBClientSDK/ACBClientVersion.h>
#import <ACBClientSDK/ACBDevice.h>
#import <ACBClientSDK/ACBMediaDirection.h>
#import <ACBClientSDK/ACBTopic.h>
#import <ACBClientSDK/ACBUC.h>
#import <ACBClientSDK/ACBUCOptions.h>
#import <ACBClientSDK/ACBVideoCaptureResolution.h>
#import <ACBClientSDK/ACBVideoCaptureSetting.h>

//! Project version number for ACBClientSDK.
FOUNDATION_EXPORT double ACBClientSDKVersionNumber;

//! Project version string for ACBClientSDK.
FOUNDATION_EXPORT const unsigned char ACBClientSDKVersionString[];
