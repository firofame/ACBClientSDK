#import <Foundation/Foundation.h>

/** A set of possible resolutions. Not all may be supported on the user's device. */
typedef NS_ENUM(NSUInteger, ACBVideoCaptureResolution)
{
    /** Automatic resolution. */
    ACBVideoCaptureResolutionAuto,
    /** CIF resolution. */
    ACBVideoCaptureResolution352x288,
    /** VGA resolution. */
    ACBVideoCaptureResolution640x480,
    /** 720p resolution. */
    ACBVideoCaptureResolution1280x720
};
